---
name: repository-audit
description: At the start of repository work.
---

# Repository Audit

## Purpose

Repository Audit guides a repeatable engineering workflow for AgencyOS.

## Activate when

At the start of repository work. Select this capability only when it applies to the request.

## Inputs

- repository tree
- local instructions

## Procedure

1. Inspect the existing project and user constraints before proposing changes.
2. Separate repository observations from assumptions and missing information.
3. Apply the smallest maintainable changes that meet the requested outcome.
4. Use relevant tools and report only checks, measurements, and outcomes supported by direct evidence.
5. Record decisions, limitations, and evidence so the work can be reviewed.

## Avoid

- Replacing suitable existing work without an audit.
- Inventing test results, measurements, evidence, or completion.
- Introducing complexity without a demonstrated requirement.
- Making high-impact or destructive changes without explicit approval.

## Expected outputs

- stack summary
- constraints
- baseline

## Validation

- existing work preserved
- commands discovered
- Report checks that were not run as unverified.
- Provide evidence references and actionable remediation for failures.
