---
name: offline-first
description: When offline use, synchronization, or unreliable networks are required.
---

# Offline and Synchronization Design

## Purpose

Offline and Synchronization Design guides a repeatable engineering workflow for AgencyOS.

## Activate when

When offline use, synchronization, or unreliable networks are required. Select this capability only when it applies to the request.

## Inputs

- offline workflows
- conflict policy
- connectivity assumptions

## Procedure

1. Inspect the existing project and user constraints before proposing changes.
2. Separate repository observations from assumptions and missing information.
3. Apply the smallest maintainable changes that meet the requested outcome.
4. Use relevant tools and report only checks, measurements, and outcomes supported by direct evidence.
5. Record decisions, limitations, and evidence so the work can be reviewed.

## Avoid

- Replacing suitable existing work without an audit.
- Inventing test results, measurements, evidence, or completion.
- Introducing complexity without a demonstrated requirement.
- Making high-impact or destructive changes without explicit approval.

## Expected outputs

- sync design
- conflict handling
- failure recovery

## Validation

- define consistency expectations
- cover retries and conflicts
- test degraded connectivity
- Report checks that were not run as unverified.
- Provide evidence references and actionable remediation for failures.
