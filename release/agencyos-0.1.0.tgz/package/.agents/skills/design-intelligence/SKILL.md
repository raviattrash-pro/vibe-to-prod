---
name: design-intelligence
description: When user-facing screens or visual systems are in scope.
---

# Design Intelligence

## Purpose

Design Intelligence guides a repeatable engineering workflow for AgencyOS.

## Activate when

When user-facing screens or visual systems are in scope. Select this capability only when it applies to the request.

## Inputs

- requirements
- audience
- references

## Procedure

1. Inspect the existing project and user constraints before proposing changes.
2. Separate repository observations from assumptions and missing information.
3. Apply the smallest maintainable changes that meet the requested outcome.
4. Use relevant tools and report only checks, measurements, and outcomes supported by direct evidence.
5. Record decisions, limitations, and evidence so the work can be reviewed.

## Avoid

- Replacing suitable existing work without an audit.
- Inventing test results, measurements, evidence, or completion.
- Introducing complexity without a demonstrated requirement.
- Making high-impact or destructive changes without explicit approval.

## Expected outputs

- design direction
- tokens
- components

## Validation

- responsive
- accessible
- original
- Report checks that were not run as unverified.
- Provide evidence references and actionable remediation for failures.
