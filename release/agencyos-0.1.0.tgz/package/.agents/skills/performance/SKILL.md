---
name: performance
description: When latency, throughput, scalability, load, or performance requirements are present.
---

# Performance Engineering

## Purpose

Performance Engineering guides a repeatable engineering workflow for AgencyOS.

## Activate when

When latency, throughput, scalability, load, or performance requirements are present. Select this capability only when it applies to the request.

## Inputs

- performance goals
- runtime measurements
- load profile

## Procedure

1. Inspect the existing project and user constraints before proposing changes.
2. Separate repository observations from assumptions and missing information.
3. Apply the smallest maintainable changes that meet the requested outcome.
4. Use relevant tools and report only checks, measurements, and outcomes supported by direct evidence.
5. Record decisions, limitations, and evidence so the work can be reviewed.

## Avoid

- Replacing suitable existing work without an audit.
- Inventing test results, measurements, evidence, or completion.
- Introducing complexity without a demonstrated requirement.
- Making high-impact or destructive changes without explicit approval.

## Expected outputs

- reproducible measurements
- budgets
- prioritized bottlenecks

## Validation

- measure actual behavior
- record the environment
- do not invent benchmarks
- Report checks that were not run as unverified.
- Provide evidence references and actionable remediation for failures.
